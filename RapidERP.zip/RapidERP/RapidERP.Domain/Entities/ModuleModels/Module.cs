﻿using RapidERP.Domain.Entities.Shared;

namespace RapidERP.Domain.Entities.ModuleModels;

public class Module : Master
{
}
