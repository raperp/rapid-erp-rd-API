﻿namespace RapidERP.Domain.Entities.Shared;
public class Master
{
    public int Id { get; set; }
    public string Name { get; set; }
}
