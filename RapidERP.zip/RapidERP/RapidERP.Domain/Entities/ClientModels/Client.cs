﻿using RapidERP.Domain.Entities.Shared;

namespace RapidERP.Domain.Entities.ClientModels;

public class Client : Master
{
}
